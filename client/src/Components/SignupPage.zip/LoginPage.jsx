import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext'; // Import your authentication context
import './LoginPage.css';

function LoginPage() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('user'); // Default to 'user'
    const navigate = useNavigate();
    const { login } = useAuth(); // Use the login function from context

    const handleSubmit = async (e) => {
        e.preventDefault();
        const response = await fetch('http://localhost:5000/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password, role }), // No need to include userId
        });
    
        if (response.ok) {
            const { token, userId } = await response.json(); // Get userId from the response
            login(token, role, userId); // Pass token, role, and userId to the login function
            // Redirect based on role
            if (role === 'admin') {
                navigate('/admin'); // Redirect to admin dashboard
            } else {
                navigate('/user'); // Redirect to user dashboard
            }
        } else {
            alert('Invalid email or password');
        }
    };

    return (
        <div className="login-container">
            <div className="login-left">
                <div className="logo">
                    <h1>CSI</h1>
                    <h3>K.K.W.I.E.E.R</h3>
                </div>
            </div>
            <div className="login-right">
                <div className="role-selector">
                    <button 
                        type="button" 
                        className={role === 'user' ? 'active' : ''} 
                        onClick={() => setRole('user')}
                    >
                        User
                    </button>
                    <button 
                        type="button" 
                        className={role === 'admin' ? 'active' : ''} 
                        onClick={() => setRole('admin')}
                    >
                        Admin
                    </button>
                </div>
                <h2>Hello, <br /> <span>Welcome!</span></h2>
                <form onSubmit={handleSubmit}>
                    <div className="input-group">
                        <label>Email Address</label>
                        <input 
                            type="email" 
                            placeholder="Enter your email" 
                            required 
                            value={email} 
                            onChange={(e) => setEmail(e.target.value)} 
                        />
                    </div>
                    <div className="input-group">
                        <label>Password</label>
                        <input 
                            type="password" 
                            placeholder="Enter your password" 
                            required 
                            value={password} 
                            onChange={(e) => setPassword(e.target.value)} 
                        />
                    </div>
                    <button type="submit">Log in</button>
                </form>
                <p>Don't have an account? <a href="/signup">Sign up</a></p>
            </div>
        </div>
    );
}

export default LoginPage;
